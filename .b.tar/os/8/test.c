/*
Name: Pranav Chandurkar
Roll no.: TI013
Date of creation : 28/03/2016
Date of modification : 29/03/2016
*/

#include<linux/kernel.h>
asmlinkage long sys_minimum(int no1,int no2)
{
	if(no1<no2)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
