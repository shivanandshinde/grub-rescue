#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>

int main(int argc,char *argv[])
{
    int a[20],n,i,j,temp;
    pid_t child_pid,temp_pid;
    int child_return_status;
    printf("\nEnter total no of elements:- ");
    scanf("%d",&n);
    printf("\nEnter the elements:- \n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("===============================================");
    for(i=0;i<n;i++)
    {
    for(j=i+1;j<n;j++)
    {
        if(a[i]>a[j])
        {
            temp=a[j];
            a[j]=a[i];
            a[i]=temp;
        }
    }
    }
    printf("\nArray after sorting:-\n");
    for(i=0;i<n;i++)
    {
        printf("%d\n",a[i]);
    }
    char **b;
    b=(char**)malloc(n*sizeof(char*));
    for(i=0;i<n;i++)
    {
        *(b+i)=(char*)malloc(n*sizeof(char));
    }
    for(i=0;i<n;i++)
    {
        sprintf(b[i],"%d",a[i]);
    }
    b[i]='\0';
    child_pid=fork();
    if(child_pid==0)
    {
        execve("c",b,NULL);
    }
    if(child_pid>0)
    {
        temp_pid=wait(&child_return_status);
    }
return 0;    
}







