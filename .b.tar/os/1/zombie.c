#include<stdio.h>
int main()
{
    int pid;
    pid=fork();
    if(pid==0)
    {
        printf("The child process id is %d :- ",getpid());
        sleep(10);
    }
    else
    {
        printf("The parent process is is %d :- ",getppid());
        sleep(30);   
    }
return 0;
}
