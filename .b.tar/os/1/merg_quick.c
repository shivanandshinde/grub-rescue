#include<stdio.h>
#define MAX 20
void mergesort(int array[MAX],int low,int mid,int high);
void quicksort(int array[MAX],int first,int last);
void partition(int array[MAX],int low,int high);

int main()
{
    int pid,array[MAX],n,i;
    printf("Enter the no of elements:- ");
    scanf("%d",&n);
    printf("Enter the elements:-\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&array[i]);
    }
    
    pid=fork();
    if(pid==0)
    {
        printf("\nChild process.............Merge Sort\n");
        partition(array,0,n-1);
        for(i=0;i<n;i++)
        {
            printf("%d",array[i]);
        }
    }
    else
    {
        printf("\nparent process.............Quick Sort");
        quicksort(array,0,n-1);
        for(i=0;i<n;i++)
        {
            printf("%d",array[i]);
        }
    }
 
return 0;    
}

void quicksort(int array[MAX],int first,int last)
{
    int pivot,i,j,temp;
    if(first<last)
    {
        pivot=first;
        i=first;
        j=last;
        while(i<j)
        {
            while(array[i]<=array[pivot] && i<last)
            i++;
            while(array[j]>array[pivot])
            j--;
            if(i<j)
            {
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
        }
        temp=array[pivot];
        array[pivot]=array[j];
        array[j]=temp;
        quicksort(array,first,j-1);
        quicksort(array,j+1,last);   
    }
}

void partition(int array[MAX],int low,int high)
{
    int mid;
    if(low<high)
    {
        mid=(low+high)/2;
        partition(array,low,mid);
        partition(array,mid+1,high);
        mergesort(array,low,mid,high);
    }
}

void mergesort(int array[MAX],int low,int mid,int high)
{
    int right,left,k,m,temp[MAX];
    left=low;
    right=low;
    m=mid+1;
    while((left<=mid)&&(m<=high))
    {
        if(array[left]<array[m])
        {
            temp[right]=array[left];
            left++;
        }
        else
        {
            temp[right]=array[m];
            m++;   
        }
        right++;
    }
    if(left>mid)
    {
        for(k=m;k<=high;k++)
        {
            temp[right]=array[k];
            right++;
        }
    }
    else
	 {
         for(k=left;k<=mid;k++)
         {
             temp[right]=array[k];
             right++;
	     }
    }
    for(k=low;k<=high;k++)
    {
        array[k]=temp[k];
    }
}










