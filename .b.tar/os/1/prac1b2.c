#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>

int main(int argc,char *argv[])
{
    int i,n,mid,m,flag=0,u,l;
    char a[20];
    printf("Child process started\n");
    for(i=0;i<argc;i++)
    {
        a[i]=atoi(argv[i]);
        printf("Sorted elements are :- %d\n",a[i]);
    }
    printf("%d",argc);
    printf("Enter the element to search:- ");
    scanf("%d",&m);
    l=0,u=argc-1;
    while(l<=u)
    {
        mid=(l+u)/2;
        if(m==a[mid])
        {
            flag=1;
            break;
        }
        else if(m<a[mid])
        {
            u=mid-1;
        }
        else
        {
            l=mid+1;
        }
    }
    if(flag==1)
    {
        printf("Element is found.\n");
    }
    else
    {
        printf("Element is not found\n");
    }
    
return 0;    
}







