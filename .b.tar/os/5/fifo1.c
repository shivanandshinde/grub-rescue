#include<stdio.h>
#include<sys/types.h>
#include <fcntl.h>
#include<unistd.h>

int main()
{
	char str[100];
	int fd;
	printf("Enter string\n");
	scanf("%s",str);
	
	mkfifo("/tmp/fifo1",0660);
	fd = open("/tmp/fifo1",O_WRONLY);
	write(fd,str,sizeof(str));
   close(fd);
  
  return 0;	
}
