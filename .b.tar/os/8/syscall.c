/*
Name: Pranav chandurkar
Roll no.: TI013
Date of creation : 28/03/2016
Date of modification : 29/03/2016
*/

#include<stdio.h>
#include<linux/unistd.h>
#include<sys/syscall.h>
#include<string.h>
#define sys_minimum 354
int main()
{
	int no1,no2,ret;
	
	printf("\n enter the Two number : ");
	scanf("%d%d",&no1,&no2);
	ret=syscall(sys_minimum,no1,no2);
	if(ret=0)
	{
		printf("Number 1 is Small ");
	}	
	else
	{
		printf("Number 2 is Small ");
	}
}
/*
&&&&&&&&& OUTPUT &&&&&&&&&&&&
student@HP800:~/vk$ gcc syscall.c
student@HP800:~/vk$ ./a.out

 enter the Two number :5
9

 Number 1 is Small 
 
 7student@HP800:~/vk$ 
*/

