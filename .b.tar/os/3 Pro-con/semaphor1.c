/*
Program No: 3
Program Name:Thread Synchronization using counting semaphores and mutual exclusion using mutex.
             Application to Demonstarte Producer-Consumer problem using counting semaphores and mutex.
Author Name:-Roshan Jha
Date Of Starting:10-2-2016
Date of Execution:12-2-2016
*/

#include<stdio.h>
#include<semaphore.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>

# define MAX 5

sem_t mutex,full,empty;
int buff[MAX];

void put(int);
int get(int);
void producer();
void consumer();

void main()
{
	pthread_t td1,td2;

	sem_init(&mutex,0,1);
	sem_init(&full,0,1);
	sem_init(&empty,0,MAX);
	
	pthread_create(&td1,NULL,(void *)producer,NULL);
	pthread_create(&td2,NULL,(void *)consumer,NULL);
	
	pthread_join(td1,NULL);
	pthread_join(td2,NULL);
	
}

void producer(void *arg)
{
	int i;

	for(i=0;i<MAX;i++)
	{
		sem_wait(&empty);
		sem_wait(&mutex);

		printf("Item Produced:%d\n",i+1);

		put(i);
		sleep(1);
		sem_post(&mutex);
		sem_post(&full);
		
	}

}

void consumer(void *arg)
{
	int item,i;
	
	for(i=0;i<MAX;i++)
	{
		sem_wait(&full);
		sem_wait(&mutex);
		
		item=get(i);
		printf("\n\tItem Consumed:%d\n",item+1);
		printf("Remaining Item:%d\n",MAX-i-1);
		sleep(1);

		sem_post(&mutex);
		sem_post(&empty);
	}
}

int get(int i)
{
	return buff[i];
}

void put(int i)
{
	 buff[i]=i;
	
}

/* Output:
student@HP800:~/TE$ gcc semaphor1.c -lpthread
student@HP800:~/TE$ ./a.out
Item Produced:1
Item Produced:2
Item Produced:3
Item Produced:4
Item Produced:5

	Item Consumed:1
Remaining Item:4

	Item Consumed:2
Remaining Item:3

	Item Consumed:3
Remaining Item:2

	Item Consumed:4
Remaining Item:1

	Item Consumed:5
Remaining Item:0
student@HP800:~/TE$ 

*/

