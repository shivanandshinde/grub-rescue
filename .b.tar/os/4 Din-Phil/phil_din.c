/*
Program No:4
Program Name:WAP in C to implement Dead-Lock free solution for the Dining Philosopher Problem.
Author Name:Roshan Jha
Date of Creation:4/3/2016
Date of Modification:4/3/2016
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<unistd.h>
#include<wait.h>
#include<semaphore.h>

#define N 5
#define THNK 0
#define HNG 1
#define EAT 2
#define LEFT (ph_no+4)%N
#define RIGHT (ph_no+1)%N

int state[N],ph_no[N]={0,1,2,3,4};

void philosopher(void *num);
void take_fork(int);
void put_fork(int);
void test(int);

sem_t mutex;
sem_t s[N];

void main()
{
  int i;
  
  pthread_t th_id[N];
  sem_init(&mutex,0,1);
  
  for(i=0;i<N;i++)
  {
     sem_init(&s[i],0,0);
  }
  
  for(i=0;i<N;i++)
  {
    pthread_create(&th_id[i],NULL,philosopher,&ph_no[i]);
    
    printf("\n Philosopher %d is THINKING. \n \n",i+1);
  }
  
  for(i=0;i<N;i++) 
  {
    pthread_join(th_id[i],NULL);
  }
   
       
}


void philosopher(void *num)
{
   while(1)
   {
     int *i=num;
     sleep(1);
     take_fork(*i);
     sleep(0);
     put_fork(*i);
   }
}


void take_fork(int ph_no)
{
   sem_wait(&mutex);
   state[ph_no]=HNG;
   printf("\n Philosopher %d is HUNGRY. \n \n",ph_no+1);
   test(ph_no);
   sem_post(&mutex);

   sem_wait(&s[ph_no]);
   sleep(1);

}

void put_fork(int ph_no)
{
  sem_wait(&mutex);
  
  state[ph_no]=THNK;
  
  printf("\n Philosopher %d is THINKING. \n ",ph_no+1);
  
  test(RIGHT);
  test(LEFT);
  
  sem_post(&mutex);
}

void test(int ph_no)   //check
{
  if(state[ph_no]==HNG && state[LEFT]!=EAT && state[RIGHT]!=EAT)
  {
     state[ph_no]=EAT;
     
     sleep(2);
     
     printf("\n Philosopher %d is EATING. \n \n",ph_no+1);
     
     sem_post(&s[ph_no]);
  }
}

/*

Output:
root@root:~$ gcc phil_din.c -lpthread
root@root:~$ ./a.out

 Philosopher 1 is THINKING. 
 

 Philosopher 2 is THINKING. 
 

 Philosopher 3 is THINKING. 
 

 Philosopher 4 is THINKING. 
 

 Philosopher 5 is THINKING. 
 

 Philosopher 1 is HUNGRY. 
 

 Philosopher 1 is EATING. 
 

 Philosopher 5 is HUNGRY. 
 

 Philosopher 4 is HUNGRY. 
 

 Philosopher 4 is EATING. 
 

 Philosopher 2 is HUNGRY. 
 

 Philosopher 3 is HUNGRY. 
 

 Philosopher 1 is THINKING.

root@root:~$

*/

