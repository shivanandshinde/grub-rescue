//matrix multiplication using thread.
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

void * mult(void *par);
int mat1[10][10];
int mat2[10][10];
int rest[10][10];
int r1,r2,c1,c2;
int i,j,k;
int sum=0,thread=0;

struct data
{
    int i;
    int j;
}D;

int main()
{
    printf("Enter the no of rows of matrix 1:- ");
    scanf("%d",&r1);
    printf("Enter the no of colms of matrix 1:- ");
    scanf("%d",&c1);
    printf("Enter the matrix 1:-\n");
    for(i=0;i<r1;i++)
    {
    for(j=0;j<c1;j++)
    {
        printf("Enter[%d][%d]:-",i,j);
        scanf("%d",&mat1[i][j]);
    }
    }
    
    printf("Enter the no of rows of matrix 2:- ");
    scanf("%d",&r2);
    printf("Enter the no of colms of matrix 2:- ");
    scanf("%d",&c2);
    printf("Enter the matrix 1:-\n");
    for(i=0;i<r2;i++)
    {
    for(j=0;j<c2;j++)
    {
        printf("Enter[%d][%d]:-",i,j);
        scanf("%d",&mat2[i][j]);
    }
    }
    
    printf("Matrix 1 is:-\n");
    for(i=0;i<r1;i++)
    {
    for(j=0;j<c1;j++)
    {
        printf("%d",mat1[i][j]);
        printf("\t");
    }
        printf("\n");
    }

    printf("Matrix 2 is:-\n");
    for(i=0;i<r2;i++)
    {
    for(j=0;j<c2;j++)
    {
        printf("%d",mat2[i][j]);
        printf("\t");
    }
        printf("\n");
    }

    if(c1!=r2)
    {
        printf("Multiplication can not possible");
    }
    else
    {
        for(i=0;i<r1;i++)
        {
        for(j=0;j<c2;j++)
        {
            struct data *D=(struct data *) malloc(sizeof(struct data));
            D->i=i;
            D->j=j;
            pthread_t t1;
            pthread_create(&t1,NULL,mult,D);
            pthread_join(t1,NULL);
            thread=thread+1;
        }
        }
    }
    
    printf("Product of entered matrix:-\n");
    for(i=0;i<r1;i++)
    {
    for(j=0;j<c2;j++)
    {
        printf("%d",rest[i][j]);
        printf("\t");
    }
        printf("\n");
    }

    printf("No of threads required is:-%d\n",thread);
return 0;
}


void* mult(void *par)
{
    struct data *D=par;
    int z,sum=0;
    for(z=0;z<c1;z++)
    {
        sum=sum+mat1[D->i][z]*mat2[z][D->j];
        rest[D->i][D->j]=sum;
    }
    pthread_exit(0);
}



