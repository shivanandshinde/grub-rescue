#include<stdio.h>
#include<sys/types.h>
#include <fcntl.h>
#include<unistd.h>

int main()
{
	int i,j,len=0,fd;
	char str[100],rev[100];
	fd = open("/tmp/fifo1",O_RDONLY);
	read(fd,str,100);
	
	printf("Accepted string is %s\n",str);
	
	for(i=0;i<100;i++)
	{
		if(str[i]!='\0')
			len++;
		else break;	
	}
	j=len-1;
	for(i=0;i<len;i++)
	{
		rev[i]=str[j];
		j--;
	}
	rev[i]='\0';
	
	printf("reversed string is %s\n",rev);
	return 0;
}
