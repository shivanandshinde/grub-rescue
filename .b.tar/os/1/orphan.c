#include<stdio.h>
int main()
{
    int pid;
    pid=fork();
    if(pid==0)
    {
        printf("The child process id is:-%d\n",getpid());
        sleep(15);
    }
    else
    {
        printf("The parent process id is :-%d \n",getppid());
    }
return 0;
}
